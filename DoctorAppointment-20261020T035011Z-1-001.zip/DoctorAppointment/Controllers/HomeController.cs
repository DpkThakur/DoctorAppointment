using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using DoctorAppointment.Models;
using System.Text.Json;
using System.Diagnostics;

namespace DoctorAppointment.Controllers
{
    public class HomeController : Controller
    {
        // Memory cache object
        private readonly IMemoryCache _memoryCache;

        // Constructor
        public HomeController(IMemoryCache memoryCache)
        {
            _memoryCache = memoryCache;
        }

        // Doctor list
        // IMemoryCache stores the doctor list for 3 minutes
        public IActionResult Index()
        {
            const string cacheKey = "DoctorList";

            // Check whether doctor list already exists in cache
            if (!_memoryCache.TryGetValue(cacheKey, out List<Doctor>? doctors))
            {
                // Create doctor list if not found in cache
                doctors = new List<Doctor>
                {
                    new Doctor
                    {
                        DoctorId = 1,
                        DoctorName = "Dr. Raj Patel",
                        Specialization = "Cardiologist",
                        Experience = 10,
                        ConsultationFee = 800
                    },

                    new Doctor
                    {
                        DoctorId = 2,
                        DoctorName = "Dr. Priya Shah",
                        Specialization = "Dermatologist",
                        Experience = 7,
                        ConsultationFee = 600
                    },

                    new Doctor
                    {
                        DoctorId = 3,
                        DoctorName = "Dr. Amit Mehta",
                        Specialization = "Orthopedic",
                        Experience = 12,
                        ConsultationFee = 900
                    },

                    new Doctor
                    {
                        DoctorId = 4,
                        DoctorName = "Dr. Neha Desai",
                        Specialization = "Pediatrician",
                        Experience = 8,
                        ConsultationFee = 700
                    }
                };

                // Cache the doctor list for 3 minutes
                var cacheOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(3));

                _memoryCache.Set(cacheKey, doctors, cacheOptions);
            }

            // Send doctor list to view
            return View(doctors);
        }

        // Doctor details page
        // Response caching is enabled for 3 minutes
        [ResponseCache(Duration = 180)]
        public IActionResult Details(int id)
        {
            // Get doctor list from cache
            const string cacheKey = "DoctorList";

            if (!_memoryCache.TryGetValue(cacheKey, out List<Doctor>? doctors))
            {
                // If cache expired, recreate doctor list
                doctors = GetDoctors();

                // Store list in cache for 3 minutes
                var cacheOptions = new MemoryCacheEntryOptions()
                    .SetAbsoluteExpiration(TimeSpan.FromMinutes(3));

                _memoryCache.Set(cacheKey, doctors, cacheOptions);
            }

            // Find doctor using DoctorId
            var doctor = doctors?.FirstOrDefault(d => d.DoctorId == id);

            // If doctor does not exist
            if (doctor == null)
            {
                return NotFound();
            }

            // Store patient name in cookie
            string? patientName = Request.Cookies["PatientName"];

            ViewBag.PatientName = patientName;

            // Send doctor information to Details view
            return View(doctor);
        }

        // Appointment GET method
        public IActionResult Appointment(int id)
        {
            // Pass DoctorId to appointment page
            ViewBag.DoctorId = id;

            return View();
        }

        // Appointment POST method
        [HttpPost]
        public IActionResult Appointment(
            int DoctorId,
            string PatientName,
            string Specialization)
        {
            // Store patient name in Cookie
            Response.Cookies.Append(
                "PatientName",
                PatientName,
                new CookieOptions
                {
                    Expires = DateTimeOffset.Now.AddDays(1),
                    HttpOnly = true
                });

            // Store specialization in Session
            HttpContext.Session.SetString(
                "Specialization",
                Specialization);

            // Display confirmation information
            ViewBag.DoctorId = DoctorId;
            ViewBag.PatientName = PatientName;
            ViewBag.Specialization = Specialization;

            return View("AppointmentConfirmation");
        }

        // Asynchronous method to retrieve posts
        public async Task<IActionResult> Posts()
        {
            // Create HttpClient
            using HttpClient client = new HttpClient();

            // Send asynchronous GET request
            var response = await client.GetAsync(
                "https://jsonplaceholder.typicode.com/posts");

            // Check if request was successful
            if (!response.IsSuccessStatusCode)
            {
                return View(new List<Post>());
            }

            // Read response content
            var json = await response.Content.ReadAsStringAsync();

            // Convert JSON into list of Post objects
            var posts = JsonSerializer.Deserialize<List<Post>>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            // Send posts to view
            return View(posts);
        }

        // Helper method to create doctor list
        private List<Doctor> GetDoctors()
        {
            return new List<Doctor>
            {
                new Doctor
                {
                    DoctorId = 1,
                    DoctorName = "Dr. Raj Patel",
                    Specialization = "Cardiologist",
                    Experience = 10,
                    ConsultationFee = 800
                },

                new Doctor
                {
                    DoctorId = 2,
                    DoctorName = "Dr. Priya Shah",
                    Specialization = "Dermatologist",
                    Experience = 7,
                    ConsultationFee = 600
                },

                new Doctor
                {
                    DoctorId = 3,
                    DoctorName = "Dr. Amit Mehta",
                    Specialization = "Orthopedic",
                    Experience = 12,
                    ConsultationFee = 900
                },

                new Doctor
                {
                    DoctorId = 4,
                    DoctorName = "Dr. Neha Desai",
                    Specialization = "Pediatrician",
                    Experience = 8,
                    ConsultationFee = 700
                }
            };
        }
    }

    // Model used to store API post information
    public class Post
    {
        // Post ID
        public int Id { get; set; }

        // Post title
        public string Title { get; set; } = "";

        // Post body
        public string Body { get; set; } = "";
    }
}