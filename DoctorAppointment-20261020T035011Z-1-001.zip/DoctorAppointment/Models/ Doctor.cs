using System.ComponentModel.DataAnnotations;

namespace DoctorAppointment.Models
{
    // Doctor model stores doctor information
    public class Doctor
    {
        // Unique ID of doctor
        public int DoctorId { get; set; }

        // Doctor's name
        public string DoctorName { get; set; } = "";

        // Doctor's specialization
        public string Specialization { get; set; } = "";

        // Years of experience
        public int Experience { get; set; }

        // Doctor's consultation fee
        public decimal ConsultationFee { get; set; }

        // Method to calculate total charge
        // It adds ₹100 service charge
        public decimal CalculateTotalCharge()
        {
            return ConsultationFee + 100;
        }
    }
}