namespace DoctorAppointment.Models
{
    // Extension methods for Doctor class
    public static class DoctorExtensions
    {
        // Extension method to calculate total consultation charge
        public static decimal CalculateTotalCharge(this Doctor doctor)
        {
            // Add ₹100 service charge
            return doctor.ConsultationFee + 100;
        }
    }
}