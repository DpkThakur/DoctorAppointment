using Microsoft.Extensions.Caching.Memory;

var builder = WebApplication.CreateBuilder(args);

// Add MVC services
builder.Services.AddControllersWithViews();

// Enable Session
builder.Services.AddSession(options =>
{
    // Session will expire after 20 minutes
    options.IdleTimeout = TimeSpan.FromMinutes(20);

    // Prevent client-side access to session cookie
    options.Cookie.HttpOnly = true;

    // Make session cookie essential
    options.Cookie.IsEssential = true;
});

// Register Memory Cache
builder.Services.AddMemoryCache();

// Add Response Caching
builder.Services.AddResponseCaching();

var app = builder.Build();

// Enable static files
app.UseStaticFiles();

// Enable routing
app.UseRouting();

// Enable Response Caching
app.UseResponseCaching();

// Enable Session
app.UseSession();

// Enable authorization
app.UseAuthorization();

// Configure default MVC route
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();